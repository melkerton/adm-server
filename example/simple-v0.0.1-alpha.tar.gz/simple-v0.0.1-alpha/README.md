Simple example for v0.0.1

From this directory:

Make sure adms*.exe and pipe-example.py are executable:

$ make setup

Start the server (assumes port 7777 is open):

$ make start

Test a data response:

$ make test-data

Test a pipe response

$ make test-pipe

